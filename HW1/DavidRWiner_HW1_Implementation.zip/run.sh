#!/bin/sh
python3.5 cross_validation.py